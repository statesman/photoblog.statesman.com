=== ShareThis ===
Tags: email, e-mail, bookmark, social, network, digg, del.icio.us, ma.gnolia, technorati, reddit, tailrank, furl, blinklist, blogmarks, newsvine, facebook, myspace, social, socialize, stumbleupon, aim, google bookmarks, windows live, yahoo my web
Contributors: alexkingorg, ShareThis
Requires at least: 1.5
Tested up to: 2.6
Stable tag: 2.3

ShareThis plugin allows users to add your post to many social bookmarking sites, or to send your post link via email, AIM, Facebook, MySpace and more.

== Description ==

The ShareThis WordPress plugin provides a quick, simple to use, and unobtrusive way for users to add your post to many social bookmarking sites, or to send your post link via email, AIM, Facebook, MySpace and more.

Be sure to start here:

http://sharethis.com/wordpress

to customize the look of the ShareThis widget on your site as well as register for tracking of your sharing events.


== Installation ==

1. Download the plugin archive and expand it (you've likely already done this).
2. Put the 'sharethis.php' file into your wp-content/plugins/ directory.
3. Go to the Plugins page in your WordPress Administration area and click 'Activate' for ShareThis.
4. (Optional) Use the the customizing tool to choose options for how to display your ShareThis window:

http://sharethis.com/wordpress

then copy the code provided and paste it into the box in Options > ShareThis and click the update button.
5. (Optional) On the ShareThis Options page, choose if you want to automatically add ShareThis to your posts and pages, or if you want to add the template tag to your theme.


== Stats and Reporting ==

If you would like to receive free stats and reporting, sign up for a publisher account:

http://sharethis.com/register


== Frequently Asked Questions ==

Please see our FAQs online:

http://support.sharethis.com/publishers


== Support ==

Have questions or suggestions for us? Perhaps it's already answered or being discussed in the ShareThis forums:

http://forums.sharethis.com


== What's Changed? ==

We maintain a list of changes to the ShareThis WordPress plugin and the ShareThis widget here:

http://sharethis.com/versionhistory


== Screenshots ==

1. A view of the ShareThis button on your posts
2. The configuration page for the widget that displays when your ShareThis button is clicked
3. Sample tracking reports available to registered ShareThis publishers