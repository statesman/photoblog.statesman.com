=== iNove ===
Contributors: mg12
Tags: two columns, fixed width, widget ready, paged comment ready, right sidebar, white, stylish, valid CSS, valid XHTML, admin options
Requires at least: 2.5
Tested up to: 2.7 beta3
Stable tag: 1.1.1

== Description ==

iNove theme inspired by MacZone. It is very stylish, widget supported and doesn’t require any plugin.

Tested on WordPress 2.3.3/2.5.1/2.6.3/2.7 beta3, with IE 6/7, Firefox 3, Opera 9 and Safari 3.1.2.
Valid XHTML 1.1 and CSS 3!
Best view under 1024×768 or greater.

== Suggested Languages ==

US English/en_US (default)
简体中文/zh_CN (translate by mg12)
Danish/da_DK (translate by Soeren Eskildsen)
German/de_DE (translate by Nicola Tiling)
Norwegian/nb_NO (translate by Rune Gulbrandsøy)
Spanish/es_ES (translate by Alberto Gonzalez)

== Suggested Plugins ==

SRG Clean Archives: http://www.idunzo.com/projects/clean-archives/
WP-PageNavi: http://lesterchan.net/portfolio/programming.php
WP23 Related Posts: http://fairyfish.net/2007/09/12/wordpress-23-related-posts-plugin/
WP-RecentComments: http://www.neoease.com/plugins/
Highslide4WP: http://www.neoease.com/plugins/
WP-Syntax: http://wordpress.org/extend/plugins/wp-syntax/

== Demo ==

http://demo.neoease.com/index.php?wptheme=iNove

== Screenshot ==

http://www.flickr.com/photos/21673317@N02/2952721477/
